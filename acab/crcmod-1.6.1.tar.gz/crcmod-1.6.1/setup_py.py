from distutils.core import setup

setup(
name='crcmod',
version='1.6.1',
description='CRC Generator',
author='Ray Buvel',
author_email='rlbuvel@gmail.com',
url='http://crcmod.sourceforge.net/',
packages=['crcmod'],

)
